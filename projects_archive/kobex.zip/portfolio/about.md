# Kobe X

Meanwhile, another dozen are in the home stretch on Kobe. Months back, we brought Nike an idea to elevate brand storytelling through physical sensation. It opened up a door into the release of the Kobe X, and in a little over 3 months we concepted, designed and developed an immersive Mobile experience, that blends the story of the shoe and the Athlete, through audio, interaction animation, and sensation. I'll let Kira send it out once it's ready (because it's fucking awesome) but it's a huge win for R/GA, a huge never-been-done-before for Nike, and the most importance element of Nike's story of the Kobe X. 

## email from Kira

Hi Everyone,

I am excited to share new work from the Nike Basketball team! Last week, we launched a mobile specific site in support of the new Kobe X and let me tell you, it has everything!  The site allows you to interact with the shoe through webGL technology, incorporates haptic sensation, tilt control, touch base navigation, and audio from Kobe himself.

This project is a big win for R/GA.  It is an amazing example of how proactively bringing innovation to our clients can drive the relationships and types of work we do.

Make sure to check out the experience on your mobile phone:  www.nike.com/kobe 

PRODUCTION

- Sam Levy
- Kira Doyle

VISUAL 

- Sammi Needham
- Ras Wangelin
- Martin Berggren
- Felipe Ferreira
- Alex Otto
- Mariola Bruszewska
- Wayne Sun

EXPERIENCE DESIGN

- Xavi Gallego

COPY

- Simeon Croker

TECH

- Nauman Hafiz
- Jason McCoskery
- Gerardo Rodriguez
- Jack Bishop

QA

- Richard Kriheli
- Michael Grater
- Brian Addison

PLANNING

- Will Perkins

Enjoy!
Kira

Kira Doyle Senior Producer
Phone 339-788-1015 kira.doyle@rga.com 
