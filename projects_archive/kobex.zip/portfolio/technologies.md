# Kobe X

## Technologies

### HTML5
	
- [Vibration API](https://developer.mozilla.org/en-US/docs/Web/API/Navigator/vibrate)
- [Device Orientation API](https://developer.mozilla.org/en-US/docs/Web/API/Detecting_device_orientation)
- Audio API
	- [SoundJS library](http://createjs.com/SoundJS)
		- A JavaScript library that provides a simple API, and powerful features to make working with audio a breeze. Easily ties in audio file loading to PreloadJS.
		- SoundJS abstracts HTML5 sound implementation, making adding consistent cross-browser sound to your games or rich experiences much easier. You can query for capabilities, then specify and prioritize what APIs, plugins, and features are leveraged for specific devices or browsers.
- Canvas
	- WebGL
		- [three.js](http://threejs.org/)
			- Three.js is a library that makes WebGL - 3D in the browser - easy to use. While a simple cube in raw WebGL would turn out hundreds of lines of Javascript and shader code, a Three.js equivalent is only a fraction of that.
	- 3D model of shoe (provided by Nike)
		- (provide more details?)

### Javascript

- No JS framework, just basic JS modules in the form of object literal notation.
- jQuery
- Handlebars
- [Hammer.js](http://hammerjs.github.io/)
	- Hammer is a open-source library that can recognize gestures made by touch, mouse and pointerEvents. It doesn't have any dependencies, and it's small, only 3.96 kB minified + gzipped!
- [GreenSock JS](http://greensock.com/gsap) Animation library

### CSS

- SCSS compiled into CSS via Grunt task

### Build Tool

- Grunt

### Package Management

- npm
- Bower

